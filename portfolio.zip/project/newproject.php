<?php
// Database configuration
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "project_database";

// Establish database connection
function connectToDatabase() {
    global $servername, $username, $password, $dbname;
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Insert new project details
function insertProject($title, $description, $image) {
    $conn = connectToDatabase();
    $title = mysqli_real_escape_string($conn, $title);
    $description = mysqli_real_escape_string($conn, $description);
    $image = mysqli_real_escape_string($conn, $image);
    
    $sql = "INSERT INTO projects (Title, Description, Image) VALUES ('$title', '$description', '$image')";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
    $conn->close();
}

// Retrieve project data
function getProjects() {
    $conn = connectToDatabase();
    $sql = "SELECT * FROM projects";
    $result = $conn->query($sql);
    $projects = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
    }
    $conn->close();
    return $projects;
}

// Update project information
function updateProject($id, $title, $description, $image) {
    $conn = connectToDatabase();
    $title = mysqli_real_escape_string($conn, $title);
    $description = mysqli_real_escape_string($conn, $description);
    $image = mysqli_real_escape_string($conn, $image);
    
    $sql = "UPDATE projects SET Title='$title', Description='$description', Image='$image' WHERE ID=$id";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
    $conn->close();
}

// Delete project
function deleteProject($id) {
    $conn = connectToDatabase();
    $sql = "DELETE FROM projects WHERE ID=$id";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
    $conn->close();
	// Insert a new project
if (insertProject("Project Title", "Project Description", "project_image.jpg")) {
    echo "Project inserted successfully.";
} else {
    echo "Error inserting project.";
}

// Retrieve and display project data
$projects = getProjects();
foreach ($projects as $project) {
    echo "Project ID: " . $project['ID'] . "<br>";
    echo "Title: " . $project['Title'] . "<br>";
    echo "Description: " . $project['Description'] . "<br>";
    echo "Image: " . $project['Image'] . "<br>";
    echo "<br>";
}

// Update project information
if (updateProject(1, "Updated Title", "Updated Description", "updated_image.jpg")) {
    echo "Project updated successfully.";
} else {
    echo "Error updating project.";
}

// Delete a project
if (deleteProject(2)) {
    echo "Project deleted successfully.";
} else {
    echo "Error deleting project.";
}

}
?>


