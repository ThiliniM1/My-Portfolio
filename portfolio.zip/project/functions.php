<?php

// Function to perform form validation and return an array of error messages
function validateForm($formData) {
    $errors = array();

    // Perform validation checks and populate the $errors array
    // Example validation: Check if fields are empty
    if (empty($formData['title'])) {
        $errors[] = "Title is required.";
    }
    if (empty($formData['description'])) {
        $errors[] = "Description is required.";
    }

    // Add more validation rules as needed

    return $errors;
}

// Function to establish a database connection and return the connection object
function connectDatabase() {
    $servername = "localhost";
    $username = "your_username";
    $password = "your_password";
    $dbname = "project_database";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Function to insert project details into the database
function insertProject($title, $description, $image) {
    $conn = connectDatabase();

    // Sanitize inputs before inserting into the database
    $title = mysqli_real_escape_string($conn, $title);
    $description = mysqli_real_escape_string($conn, $description);
    $image = mysqli_real_escape_string($conn, $image);

    $sql = "INSERT INTO projects (Title, Description, Image) VALUES ('$title', '$description', '$image')";
    $result = $conn->query($sql);

    $conn->close();
    return $result;
}

// Function to retrieve project data from the database
function getProjects() {
    $conn = connectDatabase();
    $sql = "SELECT * FROM projects";
    $result = $conn->query($sql);
    $projects = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
    }

    $conn->close();
    return $projects;
}

// Function to update project information in the database
function updateProject($id, $title, $description, $image) {
    $conn = connectDatabase();

    // Sanitize inputs before updating the database
    $title = mysqli_real_escape_string($conn, $title);
    $description = mysqli_real_escape_string($conn, $description);
    $image = mysqli_real_escape_string($conn, $image);

    $sql = "UPDATE projects SET Title='$title', Description='$description', Image='$image' WHERE ID=$id";
    $result = $conn->query($sql);

    $conn->close();
    return $result;
}

// Function to delete projects from the database
function deleteProject($id) {
    $conn = connectDatabase();
    $sql = "DELETE FROM projects WHERE ID=$id";
    $result = $conn->query($sql);

    $conn->close();
    return $result;
}

?>
