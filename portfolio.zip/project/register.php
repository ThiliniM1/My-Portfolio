<?php
function registerUser($username, $password) {
    $conn = connectToDatabase(); // Create a function to establish database connection
    
    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Validate and sanitize username (you can add more validation here)
    $username = mysqli_real_escape_string($conn, $username);
    
    // Check if username is already taken
    $checkQuery = "SELECT * FROM users WHERE Username='$username'";
    $checkResult = $conn->query($checkQuery);
    
    if ($checkResult->num_rows > 0) {
        return false; // Username already exists
    }
    
    // Insert new user details
    $insertQuery = "INSERT INTO users (Username, Password) VALUES ('$username', '$hashedPassword')";
    if ($conn->query($insertQuery)) {
        return true; // Registration successful
    } else {
        return false; // Registration failed
    }
    
    $conn->close();
}

function loginUser($username, $password) {
    $conn = connectToDatabase(); // Create a function to establish database connection
    
    // Validate and sanitize username
    $username = mysqli_real_escape_string($conn, $username);
    
    // Retrieve user details
    $getUserQuery = "SELECT * FROM users WHERE Username='$username'";
    $userResult = $conn->query($getUserQuery);
    
    if ($userResult->num_rows == 1) {
        $user = $userResult->fetch_assoc();
        if (password_verify($password, $user['Password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['ID'];
            $_SESSION['username'] = $user['Username'];
            return true; // Login successful
        }
    }
    
    return false; // Login failed
    
    $conn->close();
}

// Start the session at the beginning of your PHP scripts
session_start();

// After successful login, use $_SESSION to access user information
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $username = $_SESSION['username'];
    
    // You can use these variables to personalize the user experience
}

// To log out, destroy the session
function logoutUser() {
    session_unset();
    session_destroy();
}

// Registration
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (registerUser($username, $password)) {
        echo "Registration successful.";
    } else {
        echo "Registration failed.";
    }
}

// Login
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (loginUser($username, $password)) {
        echo "Login successful.";
    } else {
        echo "Login failed.";
    }
}

// Logout
if (isset($_POST['logout'])) {
    logoutUser();
    echo "Logged out.";
}
?>